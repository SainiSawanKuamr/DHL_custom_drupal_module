<?php
/**
 * @file
 * Contains \Drupal\locationform\Controller\DisplayController.
 */

namespace Drupal\locationform\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Code\Database\Database;
use Drupal\Component\Serialization\Json;

/**
 * Class Display.
 *
 * @package Drupal\locationform\Controller
 */
class DisplayController extends ControllerBase {

  /**
   * showdata.
   *
   * @return string
   *   Return Table format data.
   */
  public function showdata() {

// you can write your own query to fetch the data I have given my example.
    $query  = \Drupal::database();
    $result = $query->select('locationform', 'n')
            ->fields('n', array('id', 'country_name', 'city_name','postal_code'))
            ->execute()->fetchAll(\PDO::FETCH_OBJ);
// Create the row element.
    $rows = array();
    foreach ($result as $row => $content) {
      $rows[] = array(
        'data' => array($content->id, $content->country_name, $content->city_name, $content->postal_code));
    }

    $header = array('id', 'country_name', 'city_name', 'postal_code');
    $output = array(
      '#type' => 'table',    // Here you can write #type also instead of #theme.
      '#header' => $header,
      '#rows' => $rows,
    );

    return [$output,'#title'=>'Location List'];

  }

}
