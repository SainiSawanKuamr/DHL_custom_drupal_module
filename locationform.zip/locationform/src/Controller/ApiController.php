<?php
/**
 * @file
 * Contains \Drupal\locationform\Controller\DisplayController.
 */

namespace Drupal\locationform\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Code\Database\Database;
use Drupal\Component\Serialization\Json;

/**
 * Class Display.
 *
 * @package Drupal\locationform\Controller
 */
class ApiController extends ControllerBase {

  /**
   * showdata.
   *
   * @return string
   *   Return Table format data.
   */
  public function showapidata() {

    $response = \Drupal::httpClient()
    ->get('https://dummyapi.online/api/users');

    $json_string = (string) $response->getBody();
    $json_array = json_decode($json_string);

     //dd($json_array);exit;
    $rows = array();
    foreach ($json_array as $row => $content) {
      $rows[] = array(
        'data' => array($content->id, $content->name, $content->username, $content->email));
    }


    $header = array('id', 'name', 'usernane', 'postal_code');
    $output = array(
      '#type' => 'table',    // Here you can write #type also instead of #theme.
      '#header' => $header,
      '#rows' => $rows,
    );

    return [$output,'#title'=>'Location API List'];
  }

}
