<?php
/**
 * @file
 * Contains \Drupal\locationform\Form\LocationForm.
 */
namespace Drupal\locationform\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

class LocationForm extends FormBase {
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'demo_registration_form';
  }
  
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['country_name'] = array(
      '#type' => 'textfield',
      '#title' => t('Enter Name:'),
      '#required' => TRUE,
    );
    $form['city_name'] = array(
      '#type' => 'textfield',
      '#title' => t('Enter City:'),
      '#required' => TRUE,
    );
    $form['postal_code'] = array (
      '#type' => 'textfield',
      '#title' => t('Postal Code:'),
      '#required' => TRUE,
    );
    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Register'),
      '#button_type' => 'primary',
    );
    return $form;
  }
  
  public function validateForm(array &$form, FormStateInterface $form_state) {
    if(strlen($form_state->getValue('postal_code')) < 8) {
      $form_state->setErrorByName('postal_code', $this->t('Please enter a valid Postal Number'));
    }
    
  }
  
  public function submitForm(array &$form, FormStateInterface $form_state) {
    \Drupal::messenger()->addMessage(t("Demo Practice Registration Done!! Registered Values are:"));
	foreach ($form_state->getValues() as $key => $value) {
	  \Drupal::messenger()->addMessage($key . ': ' . $value);

    }

    $values = $form_state->getValues();
    \Drupal::database()->insert('locationform')->fields([
      'country_name' =>$values['country_name'],
      'city_name' =>$values['city_name'],
      'postal_code' =>$values['postal_code'],
    ])->execute();
  }

}
